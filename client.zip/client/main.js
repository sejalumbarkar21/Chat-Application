// Connect to backend Socket.IO server
const socket = io("http://localhost:3000");

// Select important elements from the HTML
const chatArea = document.getElementById("chatArea");
const input = document.querySelector(".inputbar input");
const sendBtn = document.querySelector(".sendbtn");

// Ask user for a name
let username = prompt("Enter your name:") || "User";

// Notify the server that this user joined
socket.emit("join", { username });

// Show join message locally
addSystemMessage(`${username} joined the chat`);

// When send button clicked or Enter key pressed
sendBtn.onclick = sendMessage;
input.addEventListener("keypress", (e) => {
  if (e.key === "Enter") sendMessage();
});

// Function to send message
function sendMessage() {
  const text = input.value.trim();
  if (!text) return;

  // Send to server
  socket.emit("send", text);

  // Show locally (right side bubble)
  addMessage(username, text, true);

  // Clear input
  input.value = "";
}

// Receive message from others (server broadcasts only to other clients)
socket.on("message", (data) => {
  // server won't send this message back to the sender (we use socket.broadcast on server)
  // so it's safe to always render it as "other"
  addMessage(data.user, data.text, false);
});


// Receive system messages (join/leave)
socket.on("system", (msg) => addSystemMessage(msg));

// Add a chat bubble
function addMessage(user, text, isMe) {
  const div = document.createElement("div");
  div.className = "bubble " + (isMe ? "me" : "other");
  div.innerHTML = `
    <div>${text}</div>
    <div class="meta">${user} • ${new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })}</div>
  `;
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}

// Add a system message (centered gray text)
function addSystemMessage(msg) {
  const div = document.createElement("div");
  div.className = "system";
  div.textContent = msg;
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}
